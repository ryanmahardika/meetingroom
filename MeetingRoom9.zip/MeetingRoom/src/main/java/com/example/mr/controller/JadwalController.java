package com.example.mr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.example.mr.model.Ruangan;
import com.example.mr.services.RuanganServices;

@Controller
@SessionAttributes("penggunaaktif")
public class JadwalController {
	
	@Autowired
	RuanganServices ruanganServices;

	@RequestMapping("jadwalruanganuser")
	public String keJadwalRuangan() {
		return "jadwalruanganuser";
	}
	
	@RequestMapping("jadwalbulanuser")
	public ModelAndView keJadwalBulan(@ModelAttribute("ruangan") Ruangan r) {
		return new ModelAndView("jadwalbulanuser","listruangan",ruanganServices.getTampilRuangan());
	}
	
	
	//Controller User
	@RequestMapping("bulan")
	public ModelAndView keJadwalRuanganUser(@ModelAttribute("ruangan") Ruangan r) {
		return new ModelAndView("jadwalbulanuser","listruangan",ruanganServices.getTampilRuangan());
	}
	
}
