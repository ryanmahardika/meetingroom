package com.example.mr.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface LoginRoleRepository {

}
