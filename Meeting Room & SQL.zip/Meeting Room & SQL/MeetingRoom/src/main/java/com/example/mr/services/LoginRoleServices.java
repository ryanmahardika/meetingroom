package com.example.mr.services;

import org.springframework.stereotype.Service;

@Service
public class LoginRoleServices {

}
