-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2018 at 08:10 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mr`
--

-- --------------------------------------------------------

--
-- Table structure for table `datakerusakan`
--

CREATE TABLE `datakerusakan` (
  `id` bigint(20) NOT NULL,
  `attachmentfoto` varchar(255) DEFAULT NULL,
  `deskripsi` varchar(200) DEFAULT NULL,
  `fasilitas_rusak` varchar(100) NOT NULL,
  `kode_kerusakan` varchar(5) DEFAULT NULL,
  `status_perbaikan` varchar(20) NOT NULL,
  `tanggal_rusak` date DEFAULT NULL,
  `id_karyawan` bigint(20) DEFAULT NULL,
  `id_ruangan` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datakerusakan`
--

INSERT INTO `datakerusakan` (`id`, `attachmentfoto`, `deskripsi`, `fasilitas_rusak`, `kode_kerusakan`, `status_perbaikan`, `tanggal_rusak`, `id_karyawan`, `id_ruangan`) VALUES
(1, '', 'Mati', 'Proyektor', 'A001', 'Belum Diperbaiki', '2018-05-09', 1, NULL),
(2, '', 'Tidak Berfungsi', 'Proyektor', 'C001', 'Sudah Diperbaiki', '2018-05-03', 1, NULL),
(3, '', 'Layar Tidak Bisa Dibuka', 'Proyektor Screen', 'D001', 'Sudah Diperbaiki', '2018-05-15', 1, NULL),
(4, '', 'Mati', 'Proyektor', 'E001', 'Belum Diperbaiki', '2018-05-30', 1, NULL),
(5, '', 'Mati', 'Proyektor', 'B001', 'Belum Diperbaiki', '2018-05-31', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `datalogin`
--

CREATE TABLE `datalogin` (
  `id` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `username` varchar(15) NOT NULL,
  `idkaryawan` bigint(20) DEFAULT NULL,
  `idrole` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datalogin`
--

INSERT INTO `datalogin` (`id`, `create_date`, `created_by`, `keterangan`, `update_date`, `updated_by`, `email`, `password`, `username`, `idkaryawan`, `idrole`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, 'mahardika@gmail.com', '1234', 'ryanmahardika', 1, 1),
(2, NULL, NULL, NULL, NULL, NULL, 'anggasena@gmail.com', '12345', 'anggasena', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `datapengajuan`
--

CREATE TABLE `datapengajuan` (
  `id` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `mulai` varchar(5) DEFAULT NULL,
  `selesai` varchar(5) DEFAULT NULL,
  `status_pengajuan` varchar(25) DEFAULT NULL,
  `subjek_meeting` varchar(50) DEFAULT NULL,
  `tanggal_pemakaian` date NOT NULL,
  `id_karyawan` bigint(20) DEFAULT NULL,
  `id_ruangan` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datapengajuan`
--

INSERT INTO `datapengajuan` (`id`, `create_date`, `created_by`, `keterangan`, `update_date`, `updated_by`, `deskripsi`, `mulai`, `selesai`, `status_pengajuan`, `subjek_meeting`, `tanggal_pemakaian`, `id_karyawan`, `id_ruangan`) VALUES
(4, '2018-05-26', 'Ryan Mahardika Putra', NULL, NULL, NULL, 'Meeting Internal Kantor', '08:00', '10:00', 'Pending', 'Meeting Keuangan', '2018-05-02', 1, NULL),
(5, '2018-05-26', 'Angga Sena', NULL, NULL, NULL, 'Meeting Internal Keuangan', '08:00', '10:00', 'Pending', 'Meeting Keuangan', '2018-05-04', 2, NULL),
(6, '2018-05-26', 'Angga Sena', NULL, NULL, NULL, 'Meeting Anggaran', '08:00', '10:00', 'Diterima', 'Meeting Keuangan', '2018-05-03', 2, NULL),
(7, '2018-05-26', 'Angga Sena', NULL, NULL, NULL, 'Meeting Anggaran', '08:00', '10:00', 'Diterima', 'Meeting Keuangan', '2018-05-16', 2, NULL),
(9, '2018-05-27', 'Ryan Mahardika Putra', NULL, NULL, NULL, '', '08:00', '10:30', 'Pending', 'Meeting Internal', '2018-05-03', 1, NULL),
(10, '2018-05-27', 'Ryan Mahardika Putra', NULL, NULL, NULL, '', '08:00', '12:30', 'Pending', 'Meeting Internal', '2018-05-24', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `alamat` varchar(150) NOT NULL,
  `jabatan` varchar(10) NOT NULL,
  `ktp` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nik` varchar(10) NOT NULL,
  `no_telpon` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id`, `create_date`, `created_by`, `keterangan`, `update_date`, `updated_by`, `alamat`, `jabatan`, `ktp`, `nama`, `nik`, `no_telpon`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, 'Pamulang 2', 'Admin', '3674061209910012', 'Ryan Mahardika Putra', '1209', '08561281212'),
(2, NULL, NULL, NULL, NULL, NULL, 'Depok', 'Admin', '367406', 'Angga Sena', '1210', '0856');

-- --------------------------------------------------------

--
-- Table structure for table `loginrole`
--

CREATE TABLE `loginrole` (
  `id` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `login_role` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loginrole`
--

INSERT INTO `loginrole` (`id`, `create_date`, `created_by`, `keterangan`, `update_date`, `updated_by`, `login_role`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, 'Admin'),
(2, NULL, NULL, NULL, NULL, NULL, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `peserta`
--

CREATE TABLE `peserta` (
  `id_karyawan` bigint(20) NOT NULL,
  `id_pengajuan` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `status_hadir` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ruangan`
--

CREATE TABLE `ruangan` (
  `id` bigint(20) NOT NULL,
  `create_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `fasilitas_tambahan` varchar(100) DEFAULT NULL,
  `fasilitas_utama` varchar(100) DEFAULT NULL,
  `kapasitas` int(11) NOT NULL,
  `nama_ruangan` varchar(25) NOT NULL,
  `status_ruangan` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ruangan`
--

INSERT INTO `ruangan` (`id`, `create_date`, `created_by`, `keterangan`, `update_date`, `updated_by`, `fasilitas_tambahan`, `fasilitas_utama`, `kapasitas`, `nama_ruangan`, `status_ruangan`) VALUES
(1, NULL, NULL, 'Aktif', '2018-05-27', 'Ryan Mahardika Putra', 'Wifi, Aqua Gelas', 'Proyektor,Meja,Proyektor Screen,Kursi', 60, 'Meeting Room A', 'Tersedia'),
(2, NULL, NULL, 'Aktif', '2018-05-27', 'Ryan Mahardika Putra', 'Wifi, Kopi', 'Proyektor,Meja,Proyektor Screen,Kursi', 75, 'Meeting Room B', 'Tersedia'),
(3, NULL, NULL, 'Aktif', '2018-05-27', 'Ryan Mahardika Putra', 'Aqua Gelas, Kopi', 'Proyektor,Meja,Proyektor Screen,Kursi', 35, 'Meeting Room C', 'Tersedia'),
(4, NULL, NULL, 'Aktif', '2018-05-27', 'Ryan Mahardika Putra', 'Wifi', 'Proyektor,Meja,Proyektor Screen,Kursi', 50, 'Meeting Room D', 'Tersedia'),
(5, NULL, NULL, 'Aktif', '2018-05-27', 'Ryan Mahardika Putra', 'Kopi', 'Proyektor,Meja,Proyektor Screen,Kursi', 30, 'Meeting Room E', 'Tersedia');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datakerusakan`
--
ALTER TABLE `datakerusakan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_hqcwkpqnhs1t9efh1ws3fc0y4` (`kode_kerusakan`),
  ADD KEY `FK38gknaurjr18aumsa4hskba1s` (`id_karyawan`),
  ADD KEY `FKikhfj51f270tvq5y5su4jj9bt` (`id_ruangan`);

--
-- Indexes for table `datalogin`
--
ALTER TABLE `datalogin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_vaq6am2uqjmllvpjuti3si62` (`email`),
  ADD UNIQUE KEY `UK_9w4jygbfeu2c38ayig9wsqfbr` (`password`),
  ADD UNIQUE KEY `UK_mgtwb51b4radleqg8wlsg63lw` (`username`),
  ADD KEY `FKa1e38hfcf31k24xm3v5gxoslc` (`idkaryawan`),
  ADD KEY `FKssqjt43dnewb0xcfd2jpb952t` (`idrole`);

--
-- Indexes for table `datapengajuan`
--
ALTER TABLE `datapengajuan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK8q0ibnq70djb0xppvwmbpyldj` (`id_karyawan`),
  ADD KEY `FK5jfkxn6q7gjbd3w84pvp6xawa` (`id_ruangan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_m9k404yv31i6fxty03cf5npa7` (`nik`);

--
-- Indexes for table `loginrole`
--
ALTER TABLE `loginrole`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_l9673rno9c5x995jkfr1uxkb5` (`login_role`);

--
-- Indexes for table `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`id_karyawan`,`id_pengajuan`),
  ADD KEY `FK1cuam8gtcny4uvuy99rhssf3s` (`id_pengajuan`);

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_32ef6l2beysgnndbtn6577vet` (`nama_ruangan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datakerusakan`
--
ALTER TABLE `datakerusakan`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `datalogin`
--
ALTER TABLE `datalogin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `datapengajuan`
--
ALTER TABLE `datapengajuan`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `loginrole`
--
ALTER TABLE `loginrole`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
